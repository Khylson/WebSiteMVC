﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NorthWindMVC.Models;

namespace NorthWindMVC.Controllers
{
    public class CategoryController : Controller
    {
        private NorthWind db = new NorthWind();
        // GET: Category
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ListCategories()
        {
            var retorno = (from c in db.Categories
                           orderby c.CategoryName
                           select new
                           {
                               c.CategoryID,
                               c.CategoryName
                           }
                               ).ToList();
            return Json(retorno, JsonRequestBehavior.AllowGet);

        }
    }
}