﻿using NorthWindMVC.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWindMVC.Controllers
{
  
    public class EmployeeController : Controller
    {           // GET: Employee
        private NorthWind db = new NorthWind();
        private object trow;

        public ActionResult ListEmployeesJson( string FirstName)
        {
            var list = (from e in db.Employees
                        where (string.IsNullOrEmpty(FirstName) ? true :
                         e.FirstName.StartsWith(FirstName))
                        orderby e.FirstName
                        select e).ToList();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        public ActionResult IndexJavaScript(Employee employee)
        {
           
                      return View();
        }
        [HttpPost]
        public ActionResult DeleteJson(Employee e)
        {
            var resposta = new RespostaHtml { success = true };
            var db = new NorthWind();
            var empregado = (from emp in db.Employees
                             where emp.EmployeeID == e.EmployeeID
                             select emp).FirstOrDefault();
            if (empregado != null)
            {
                db.Employees.Remove(empregado);
                try
                {
                    db.SaveChanges();
                    resposta.Data = e.EmployeeID;
                }
                catch (Exception ex)
                {
                    ex = ErrorException(ex);
                    resposta.success = false;
                    resposta.message = ex.Message;
                }
            }
            else
            {
                var ex = new Exception("Registro não encontrado");
                resposta.message = ex.Message;
            }
            return Json(resposta, JsonRequestBehavior.DenyGet);
        }
        //esse metodo deve responder com Json
        [HttpPost]
        public ActionResult SalveJson(Employee e)
        {
            var resposta = new RespostaHtml { success = false };
            try
            {

                if (string.IsNullOrWhiteSpace(e.LastName))
                    resposta.message += "Last Name Obrigatório.";
                if (string.IsNullOrWhiteSpace(e.FirstName))
                    resposta.message += "First Name Obrigatório.";

                // Se houver alguma mensagem, gera um erro
                if (resposta.message != null)
                    throw new Exception(resposta.message);

                //usar a classe de banco de dados
                e.Adventista = e.Adventista == null ? false : true;
                if (e.EmployeeID == 0)
                {
                    db.Employees.Add(e);
                }
                else
                {
                    db.Employees.Attach(e);
                    db.Entry(e).State = EntityState.Modified;
                }
                db.SaveChanges();
                resposta.data = e;
                resposta.success = true;
            }
            catch (Exception ex)
            {
                ex = ErrorException(ex);
                resposta.success = false;
                resposta.message = ex.Message;
            }
            return Json(resposta, JsonRequestBehavior.DenyGet);
        }
        [HttpGet]
        public ActionResult ListEmployees(string id)
        {
            var listEmployee = (from e in db.Employees
                            orderby e.LastName
                            select new
                            {
                                e.EmployeeID,
                                e.LastName
                            }).ToList();
                         
            return Json(listEmployee, JsonRequestBehavior.AllowGet);
        }
        public ActionResult NewJavaScript(int? id)
        {
            Employee employee = new Employee();
            if (id != null)
            {
                employee = (from emp in db.Employees
                            where emp.EmployeeID == id
                            select emp).FirstOrDefault();
            }

            return View(employee);
        }
        public ActionResult Delete (int EmployeeID)
        {
            ViewBag.Messege = "O registro foi exluido com sucesso!";
            var db = new NorthWind();
            // Para Excluir, traga o registro do banco de dados e depois 
            // Exclua da memoria...

            var employee = (from c in db.Employees
                            where c.EmployeeID == EmployeeID
                            select c).FirstOrDefault();


            if (employee == null)
            {

                var ex = new Exception("Registro não Encontrado!");
                return View("Erro", ex);

            }
            try
            {
                db.Employees.Remove(employee);
                db.SaveChanges();

            }
            catch (Exception ex)
            {
                return View("Erro", ErrorException(ex));


            }

            // Crie uma ViewBag com lista de empregados... 

            var empregados = (from lis in db.Employees
                         select lis).ToList();
            ViewBag.listas = empregados;

            return View("New", new Employee());

        }
        public ActionResult Edit (int id)
        {
            var db = new NorthWind();
            var empregado = (from ed in db.Employees
                        where ed.EmployeeID == id
                        select ed).FirstOrDefault();
            if (empregado==null)
            {
                var ex = new Exception("Registro Não Encontrado!");
                return View("Erro", ex);
            }

            var empre = (from em in db.Employees
                       select em).ToList();

            ViewBag.listas = empre;
            return View("New", empregado);
        }
        public ActionResult Index()
        {
            var db = new NorthWind();
            var emp = (from em in db.Employees
                       select em).ToList();
            return View(emp);
        }
        public ActionResult New ()
        {
            
            var lista = (from lis in db.Employees
                         select lis).ToList();
            ViewBag.listas = lista;
            return View(new Employee());

            
        }
        public System.Exception ErrorException(System.Exception ex)
        {
            if (ex.InnerException == null)
                return ex;
            else
                return ErrorException(ex.InnerException);
        }
        [HttpPost]
        public ActionResult Save(Employee e)
        {
            var db = new NorthWind();
            try
            {
                // usar a classe do banco de dados 
                e.Adventista = e.Adventista == null ? false : true;
                if(e.EmployeeID == 0)
                {//e.Aventista = e.Adventista == null ? false : true;
                    db.Employees.Add(e);
                }
                else
                {
                    db.Employees.Attach(e);
                    db.Entry(e).State = EntityState.Modified;

                }


                // Salvar registro no banco de dados ...
            
                db.SaveChanges();
                var lista = (from lis in db.Employees
                             select lis).ToList();
                ViewBag.listas = lista;

            }
            catch (Exception ex)
            {
                ex = ErrorException(ex);
                return View("Erro", ex);

            }
            //  Se não ocorrer um erro, o que acontece? 
            ViewBag.Erros = "O registro foi Incluido com Sucesso!";
            return View("New", new Employee());
            
        }
        
    }
}