﻿using NorthWindMVC.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NorthWindMVC.Controllers
{
    public class SupplierController : Controller
    {
        private NorthWind db = new NorthWind();
        // GET: Supplier
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SalvarDados(Supplier sup)
        {
            var resposta = new RespostaHtml { success = true };
            try
            {
                //usar a classe de banco de dados
                if (sup.SupplierID == 0)
                {
                    db.Suppliers.Add(sup);
                }
                else
                {
                    db.Suppliers.Attach(sup);
                    db.Entry(sup).State = EntityState.Modified;
                }
                db.SaveChanges();
                resposta.data = sup;
            }
            catch (Exception ex)
            {
                ex = ErrorException(ex);
                resposta.success = true;
                resposta.message = ex.Message;
            }
            return Json(resposta, JsonRequestBehavior.DenyGet);
        }
        [HttpPost]
        public ActionResult DeleteJson(Supplier sup)
        {
            var resposta = new RespostaHtml { success = true };
       
            var fornecedor = (from supp in db.Suppliers
                             where supp.SupplierID == sup.SupplierID
                             select supp).FirstOrDefault();
            if (fornecedor != null)
            {
                db.Suppliers.Remove(fornecedor);
                try
                {
                    db.SaveChanges();
                    resposta.Data = sup.SupplierID;
                }
                catch (Exception ex)
                {
                    ex = ErrorException(ex);
                    resposta.success = false;
                    resposta.message = ex.Message;
                }
            }
            else
            {
                var ex = new Exception("Registro não encontrado");
                resposta.message = ex.Message;
            }
            return Json(resposta, JsonRequestBehavior.DenyGet);
        }
        public ActionResult New(int? id)
        {
            Supplier supplier = new Supplier();
            if (id != null)
            {
                supplier = (from sup in db.Suppliers
                            where sup.SupplierID == id
                            select sup).FirstOrDefault();
            }

            return View(supplier);
        }
        public ActionResult Edit(int id)
        {
            
            var supplier = (from ed in db.Suppliers
                             where ed.SupplierID == id
                             select ed).FirstOrDefault();
            if (supplier == null)
            {
                var ex = new Exception("Registro Não Encontrado!");
                return View("Erro", ex);
            }

            var supplie = (from sup in db.Suppliers
                         select sup).ToList();

            ViewBag.listas = supplie;
            return View("New", supplier);
        }
        [HttpGet]
        public ActionResult ListSupplier(string CompanyName)
        {
            var listSupplier = (from e in db.Suppliers
                        where (string.IsNullOrEmpty(CompanyName) ? true :
                         e.CompanyName.StartsWith(CompanyName))
                         
                                orderby e.CompanyName
               
                                select e).ToList();
            return Json(listSupplier, JsonRequestBehavior.AllowGet);
        }
        public System.Exception ErrorException(System.Exception ex)
        {
            if (ex.InnerException == null)
                return ex;
            else
                return ErrorException(ex.InnerException);
        }
    }
}