﻿using NorthWindMVC.Models;

namespace NorthWindMVC.Controllers
{
   public class RespostaHtml
    {
        internal Employee data;

        public bool success { get; set; }
        public string message { get; set; }
        public object Data { get; set; }
       



    }
}